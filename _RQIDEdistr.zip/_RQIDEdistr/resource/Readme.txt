To edit icons, you can download these helpful and Free editors and converters from the web:

IconEdit.exe  - 350k
IconExtractor.exe  -  406k
102,400 Imagedit.Exe  - 100k
Pic2Ico.exe  - 49k
They are not copied in this distribution for copyright reasons